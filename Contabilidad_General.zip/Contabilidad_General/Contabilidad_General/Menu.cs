﻿using System;
namespace Contabilidad_General
{
    public partial class Menu : Gtk.Dialog
    {
        public Menu()
        {
            this.Build();
        }
    }
}
