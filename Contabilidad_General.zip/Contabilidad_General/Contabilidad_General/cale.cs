﻿using System;
namespace Contabilidad_General
{
    public partial class cale : Gtk.Window
    {
        public cale() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
        }
    }
}
